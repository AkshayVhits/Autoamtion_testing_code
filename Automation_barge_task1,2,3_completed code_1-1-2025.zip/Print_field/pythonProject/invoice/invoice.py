import pyautogui
import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
# getting the URL
driver.get("https://barge.appworkdemo.com/")

#Entering the data in the email field
email = driver.find_element(By.NAME, 'email')
mailto:email.send_keys("admin@barge.com")
entered_email = email.get_attribute("value")
print(entered_email)

#Entering the data in the password field
Password = driver.find_element(By.NAME, "password")
Password.send_keys("Admin@123")
entered_password = Password.get_attribute("value")
print(entered_password)

#Clicking on the submit button
Submit_button = driver.find_element(By.XPATH, '//button[@type="submit"]')
log_message = "Clicking the submit button"
print(log_message)
Submit_button.click()
time.sleep(2)
print("Submit button clicked successfully.")


# login in end
# Click on the invoice section

Click_on_invoice = driver.find_element(By.XPATH, '(//a[@href="/admin/invoice"])[1]')
Click_on_invoice.click()
print("Invoice is been clicked")
time.sleep(3)

Click_on_invoice_add_button = driver.find_element(By.XPATH, '//a[@href="/admin/invoice/add-invoice"]')
Click_on_invoice_add_button.click()
print("Add invoice button clicked successfully")
time.sleep(5)
#party name

Party_name = driver.find_element(By.XPATH, '//input[@placeholder="Party name"]')
Party_name.click()
Party_name_1 = driver.find_element(By.XPATH, "//li[@id='combo-box-demo-option-2']")
Party_name_1.click()
time.sleep(1)
Party_name_value = Party_name.get_attribute("value")
Party_name_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[2]')
Party_name_label_text = Party_name_label.text
print(f"{Party_name_label_text}: {Party_name_value}")


#Bdn

BDN = driver.find_element(By.XPATH, '//input[@placeholder="BDN"]')
BDN.send_keys("Testing")
BDN_value = BDN.get_attribute('value')
BDN_label_text = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[3]')
BDN_label_text = BDN_label_text.text
print(f"{BDN_label_text}: {BDN_value}")


#PL_NO
PL_NO = driver.find_element(By.XPATH, '//input[@placeholder="PI_no"]')
PL_NO.send_keys("Testing test")
time.sleep(1)
PL_NO_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[4]')
PL_NO_label_text = PL_NO_label.text
PL_NO_value = PL_NO.get_attribute("value")
print(f"{PL_NO_label_text}: {PL_NO_value}")


#Exmi or Develivery

Exmi = driver.find_element(By.XPATH, '//div[@id="mui-component-select-exmiOrDelivered"]')
Exmi.click()
Exmi_1 = driver.find_element(By.XPATH, '//li[@data-value="Exmi"]')
Exmi_1.click()
time.sleep(1)
Exmi_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[5]')
Exmi_label_text = Exmi_label.text
Exmi_value = Exmi.get_attribute("value")
Exmi_selected_value = driver.find_element(By.XPATH, '//input[@name="exmiOrDelivered"]').get_attribute("value")
print(f"{Exmi_label_text}: {Exmi_selected_value}")

#Tankers Or Pipeline

Tankers = driver.find_element(By.XPATH, '//div[@id="mui-component-select-takersOrPipeline"]')
Tankers.click()
Tankers1 = driver.find_element(By.XPATH, '//li[@data-value="Tankers"]')
Tankers1.click()
time.sleep(1)
Tankers_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[6]')
Tankers_label_text = Tankers_label.text
Tankers_selected_value = Tankers.get_attribute("textContent")
Tankers_selected_value = driver.find_element(By.XPATH, '//div[@id="mui-component-select-takersOrPipeline"]').text
print(f"{Tankers_label_text}: {Tankers_selected_value}")

#Port

Port = driver.find_element(By.XPATH, '(//input[@id="combo-box-demo"])[2]')
Port.click()
Port1 = driver.find_element(By.XPATH, "//li[@id='combo-box-demo-option-2']")
Port1.click()
time.sleep(1)
Port_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[7]')
Port_label_text = Port_label.text
Port_selected_value = Port.get_attribute("value")
Port_selected_value = driver.find_element(By.XPATH, '(//input[@id="combo-box-demo"])[2]').get_attribute("value")
print(f"{Port_label_text}: {Port_selected_value}")

#PO_no

PO_no = driver.find_element(By.XPATH, '//input[@name="PO_No"]')
PO_no.send_keys("Testing test test")
time.sleep(1)
PO_no_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[8]')
PO_no_label_text = PO_no_label.text
PO_no_value = PO_no.get_attribute("value")
print(f"{PO_no_label_text}: {PO_no_value}")

#Vessel Name

Vessel_name = driver.find_element(By.XPATH, '//input[@placeholder="Vessel name"]')
Vessel_name.send_keys("India")
time.sleep(1)
Vessel_name_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[9]')
Vessel_name_label_text = Vessel_name_label.text
Vessel_name_value = Vessel_name.get_attribute("value")
print(f"{Vessel_name_label_text}: {Vessel_name_value}")


#Items

Items = driver.find_element(By.XPATH, '(//div[@aria-haspopup="listbox"])[3]')
Items.click()
Items1 = driver.find_element(By.XPATH, '//li[@data-value="HSD"]')
Items1.click()
time.sleep(1)
Items_label = driver.find_element(By.XPATH, '//th[@class="MuiTableCell-root MuiTableCell-head MuiTableCell-sizeMedium css-1bigob2"][1]')
Items_label_text = Items_label.text
Items_selected_value = Items.get_attribute("textContent")
Items_selected_value = driver.find_element(By.XPATH, '(//div[@aria-haspopup="listbox"])[3]').text
print(f"{Items_label_text}: {Items_selected_value}")


#perticulars (Service)

Particulars = driver.find_element(By.XPATH, '(//input[@id="combo-box-demo"])[3]')
Particulars.click()
Particulars1 = driver.find_element(By.XPATH, "//li[@id='combo-box-demo-option-2']")
Particulars1.click()
time.sleep(1)
Particulars_label = driver.find_element(By.XPATH, '//th[@class="MuiTableCell-root MuiTableCell-head MuiTableCell-sizeMedium css-1bigob2"][2]')
Particulars_label_text = Particulars_label.text
Particulars_selected_value = Particulars.get_attribute("value")
Particulars_selected_value = driver.find_element(By.XPATH, '(//input[@id="combo-box-demo"])[3]').get_attribute("value")
print(f"{Particulars_label_text}: {Particulars_selected_value}")


#interstate/Intrastate
Interstate = driver.find_element(By.XPATH, '(//div[@aria-haspopup="listbox"])[4]')
Interstate.click()
Interstate1 = driver.find_element(By.XPATH, '(//li[@role="option"])[2]')
Interstate1.click()
time.sleep(1)
Interstate_label = driver.find_element(By.XPATH, '//th[@class="MuiTableCell-root MuiTableCell-head MuiTableCell-sizeMedium css-1bigob2"][4]')
Interstate_label_text = Interstate_label.text
Interstate_selected_value = Interstate.get_attribute("textContent")
Interstate_selected_value = driver.find_element(By.XPATH, '(//div[@aria-haspopup="listbox"])[4]').text
print(f"{Interstate_label_text}: {Interstate_selected_value}")

#Qty In MT

QTY = driver.find_element(By.XPATH, '//input[@placeholder="Qty In MT"]')
QTY.send_keys("0.0000")
time.sleep(1)
QTY_label = driver.find_element(By.XPATH, '//th[@class="MuiTableCell-root MuiTableCell-head MuiTableCell-sizeMedium css-1bigob2"][5]')
QTY_label_text = QTY_label.text
QTY_value = QTY.get_attribute("value")
print(f"{QTY_label_text}: {QTY_value}")

#taxaable value

taxable = driver.find_element(By.XPATH, '//input[@placeholder="Taxable Value"]')
taxable.send_keys("0.00001")
time.sleep(1)
taxable_label = driver.find_element(By.XPATH, '//th[@class="MuiTableCell-root MuiTableCell-head MuiTableCell-sizeMedium css-1bigob2"][6]')
taxable_label_text = taxable_label.text
taxable_value = taxable.get_attribute("value")
print(f"{taxable_label_text}: {taxable_value}")

#Date of supply

Date = driver.find_element(By.XPATH, '//*[@id="root"]/div/div[2]/div/div/div/div[3]/div[1]/div/div[1]/div/form/div[1]/div[4]/div[1]/div/div[1]/div/div/div/div/div/div/div/button')
Date.click()
Date1 = driver.find_element(By.XPATH, '(//button[@type="button"])[22]')
Date1.click()
time.sleep(1)
Date_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[10]')  # Adjust the index as necessary
Date_label_text = Date_label.text
selected_date_value = Date.get_attribute("value")
print(f"{Date_label_text}: {selected_date_value}")


#barge

barge = driver.find_element(By.XPATH, '//div[@aria-labelledby="mui-component-select-barges"]')
barge.click()
barge1 = driver.find_element(By.XPATH, '(//li[@role="option"])[3]')
barge1.click()
time.sleep(1)
barge_label = driver.find_element(By.XPATH, '(//label[@class="MuiTypography-root MuiTypography-label input-label css-1uk1gs8"])[11]')
barge_label_text = barge_label.text
selected_barge_value = driver.find_element(By.XPATH, '//div[@aria-labelledby="mui-component-select-barges"]').text
print(f"{barge_label_text}: {selected_barge_value}")

pyautogui.moveTo(600, 700, duration=1)
pyautogui.click()
submit_button = driver.find_element(By.XPATH, '(//button[@type="submit"])[2]')
submit_button.click()
print("Clicked on submit button")
time.sleep(3)
driver.get_screenshot_as_file("test_invoice_valid.png")