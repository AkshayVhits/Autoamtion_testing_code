# import pytest
#
# def count_tests():
#     # Ensure that this function counts or logs the number of tests
#     print("Counting tests...")  # This is a placeholder for your logic
#
# if __name__ == "__main__":
#     # Run the first test file
#     pytest.main(["-v", "Logintestcase.py"])
#     pytest.main(["-v", "label_print.py"])
#     pytest.main(["-v", "invoice.py"])
#     count_tests()
#     passed_tests
#     failed tests

import pytest

passed_tests = 0
failed_tests = 0

def pytest_runtest_logreport(report):
    global passed_tests, failed_tests
    if report.outcome == 'passed':
        passed_tests += 1
    elif report.outcome == 'failed':
        failed_tests += 1

def count_tests():
    print(f"Total Passed Tests: {passed_tests}")
    print(f"Total Failed Tests: {failed_tests}")

if __name__ == "__main__":
    try:
        pytest.main(["-v", "Login/Logintestcase.py"])
        pytest.main(["-v", "Bunker/label_print.py"])
        pytest.main(["-v", "invoice/invoice.py"])
    finally:
        count_tests()




