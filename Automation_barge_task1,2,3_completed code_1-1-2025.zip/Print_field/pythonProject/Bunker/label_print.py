import os

import pytest
from selenium import webdriver
from Locator import LoginPageLocators
from Database import DataGenerator
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time



class TestLogin:
    @pytest.fixture(scope="class")
    def setup(self):
        self.driver = webdriver.Chrome()
        self.driver.get("https://barge.appworkdemo.com/")
        yield self.driver
        self.driver.quit()

    def handle_unexpected_alert(self, driver):
        try:
            WebDriverWait(driver, 5).until(ec.alert_is_present())
            alert = driver.switch_to.alert
            alert.accept()
            print("Alert handled.")
        except:
            print("No alert present.")

    def capture_screenshot(self, driver, filename):
        screenshot_dir = "screenshots"
        if not os.path.exists(screenshot_dir):
            os.makedirs(screenshot_dir)
        screenshot_path = os.path.join(screenshot_dir, f"{filename}.png")
        driver.get_screenshot_as_file(screenshot_path)
        print(f"Screenshot saved as {screenshot_path}")


    @pytest.mark.run(order=1)
    def test_for_the_valid_credentials_entered(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = 'admin@barge.com'
        password = 'Admin@123'
        driver.find_element(By.NAME, LoginPageLocators.EMAIL_FIELD).send_keys(email)
        driver.find_element(By.NAME, LoginPageLocators.PASSWORD_FIELD).send_keys(password)
        login_button = driver.find_element(By.XPATH, LoginPageLocators.LOGIN_BUTTON)
        login_button.click()
        time.sleep(5)
        driver.find_element(By.XPATH, '//a[normalize-space()="Bunker Orders"]').click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//button[normalize-space()='Add order']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[2]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//button[normalize-space()='1']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//input[@id='free-solo-with-text-demo']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//li[@id='free-solo-with-text-demo-option-0']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//div[@id='mui-component-select-exmiOrDelivered']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "/html/body/div[2]/div[3]/ul/li[2]").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//input[@placeholder='Port name']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//*[@id='combo-box-demo-option-2']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, '//input[@placeholder="Order Received From / Trader"]').click()
        time.sleep(3)
        driver.find_element(By.XPATH, "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[6]/div[1]/div[2]/div[1]/ul[1]/li[1]").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//input[@placeholder='Terminal name']").click()
        driver.find_element(By.XPATH, "//li[@id='combo-box-demo-option-1']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, '//input[@placeholder="C/F name"]').click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//li[@id='combo-box-demo-option-0']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "(//div[@aria-haspopup='listbox'])[2]").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//li[@data-value='HSD']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//input[@name='nominatedQty']").send_keys("Testing")
        time.sleep(3)
        driver.find_element(By.XPATH, '//input[@placeholder="Agent"]').send_keys("Test")
        time.sleep(3)

        #ETA
        driver.find_element(By.XPATH, "(//button[@aria-label='Choose date'])[1]").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//button[normalize-space()='12']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='5 hours']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='6 minutes']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='PM']").click()
        time.sleep(2)


        driver.find_element(By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[13]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//button[normalize-space()='13']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[contains(@aria-label,'4 hours')]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='3 minutes']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='PM']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[14]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//button[normalize-space()='19']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[contains(@aria-label,'4 hours')]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='3 minutes']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='PM']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//input[@name='stayHours']").send_keys("12")
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[@id='mui-component-select-companyName']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@data-value='BSJPL']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "(//input[@placeholder='DD/MM/YYYY'])[2]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//button[@class='MuiButtonBase-root MuiPickersDay-root MuiPickersDay-today MuiDateRangePickerDay-day MuiDateRangePickerDay-notSelectedDate MuiDateRangePickerDay-dayOutsideRangeInterval css-4n387u']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[3]//div[2]//div[2]//div[1]//div[3]//div[4]//div[1]//button[1]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, '//div[18]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]').click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[@id='mui-component-select-transportation']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[normalize-space()='OTHER']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[@class='set-date set-date-picker picker-box-set MuiBox-root css-0']//button[@aria-label='Choose date']//*[name()='svg']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//button[normalize-space()='13']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[22]//div[1]//label[1]//span[1]//input[1]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[23]//div[1]//label[1]//span[1]//input[1]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[24]//div[1]//label[1]//span[1]//input[1]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//div[25]//div[1]//label[1]//span[1]//input[1]").click()
        time.sleep(2)
        driver.execute_script("window.scrollBy(0, 600);")
        time.sleep(4)
        file_input = driver.find_element(By.XPATH, '//input[@name="nominationPdf"]')
        file_path = r"C:\Users\Lenovo\OneDrive\Pictures\ak.pdf"
        # file_path = r"C:\Users\aksha\Downloads"
        file_input.send_keys(file_path)
        time.sleep(5)
        file_input_1 = driver.find_element(By.XPATH, '//input[@name="wharfageFile"]')
        file_path_1 = r"C:\Users\Lenovo\OneDrive\Pictures\ak.pdf"
        # file_path_1 = r"C:\Users\aksha\Downloads"
        file_input_1.send_keys(file_path_1)
        time.sleep(3)
        driver.find_element(By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[20]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//button[normalize-space()='19']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[contains(@aria-label,'4 hours')]").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='3 minutes']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//li[@aria-label='PM']").click()
        time.sleep(2)
        driver.find_element(By.XPATH, "//*[@id='root']/div/div[2]/div/div/div/div[3]/div[1]/div/div/form/div[1]/div[1]/div[21]/div/div/div/div/div/div/div/button").click()
        time.sleep(3)
        driver.find_element(By.XPATH, "//button[normalize-space()='19']").click()
        time.sleep(10)

        driver.find_element(By.XPATH, "//textarea[@placeholder='Remark']").send_keys("testing test")
        time.sleep(10)

        self.capture_screenshot(driver, "test_for_the_valid_credentials_entered")

    def _perform_login(self, driver, email, password):
        driver.find_element(By.NAME, LoginPageLocators.EMAIL_FIELD).send_keys(email)
        driver.find_element(By.NAME, LoginPageLocators.PASSWORD_FIELD).send_keys(password)
        driver.find_element(By.XPATH, LoginPageLocators.LOGIN_BUTTON).click()

