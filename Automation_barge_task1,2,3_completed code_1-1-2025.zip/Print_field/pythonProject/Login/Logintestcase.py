import os
import shutil
import pytest
from selenium import webdriver
from Locator import LoginPageLocators
from Database import DataGenerator
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time

class TestLogin:

    @pytest.fixture(scope="class")
    def setup(self):
        self.driver = webdriver.Chrome()
        self.driver.get("https://barge.appworkdemo.com/")
        yield self.driver
        self.driver.quit()

    def handle_unexpected_alert(self, driver):
        try:
            WebDriverWait(driver, 5).until(ec.alert_is_present())
            alert = driver.switch_to.alert
            alert.accept()
            print("Alert handled.")
        except:
            print("No alert present.")

    def capture_screenshot(self, driver, test_name):
        screenshot_path = f"C:/Users/Lenovo/Print_field/pythonProject/screenshots/{test_name}.png"
        driver.save_screenshot(screenshot_path)
        print(f"Screenshot saved at: {screenshot_path}")
        return screenshot_path

    @pytest.mark.run(order=1)
    def test_login_with_valid_credentials(self, setup):
        driver = setup
        driver.refresh()
        time.sleep(3)
        self.handle_unexpected_alert(driver)
        email = "validuser@example.com"
        password = "validpassword"
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_valid_credentials")

    @pytest.mark.run(order=2)
    def test_login_with_invalid_email(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = "invaliduser@example.com"
        password = "validpassword"
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_invalid_email")

    @pytest.mark.run(order=3)
    def test_login_with_invalid_password(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = "validuser@example.com"
        password = "wrongpassword"
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_invalid_password")

    @pytest.mark.run(order=4)
    def test_login_with_empty_email(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = ""
        password = "validpassword"
        self._perform_login(driver, email, password)
        time.sleep(4)
        self.capture_screenshot(driver, "test_login_with_empty_email")

    @pytest.mark.run(order=5)
    def test_login_with_empty_password(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = "validuser@example.com"
        password = ""
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_empty_password")

    @pytest.mark.run(order=6)
    def test_login_with_empty_email_and_password(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = ""
        password = ""
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_empty_email_and_password")

    @pytest.mark.run(order=7)
    def test_login_with_random_email_password(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = DataGenerator.generate_random_email()
        password = DataGenerator.generate_random_password()
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_random_email_password")

    @pytest.mark.run(order=8)
    def test_login_with_special_characters_in_email(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = "special@char!$%@example.com"
        password = "validpassword"
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_special_characters_in_email")

    @pytest.mark.run(order=9)
    def test_login_with_special_characters_in_password(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)
        email = "validuser@example.com"
        password = "valid@password!123"
        self._perform_login(driver, email, password)
        time.sleep(2)
        self.capture_screenshot(driver, "test_login_with_special_characters_in_password")

    @pytest.mark.run(order=10)
    def test_login_button_enabled_when_credentials_entered(self, setup):
        driver = setup
        driver.refresh()
        self.handle_unexpected_alert(driver)

        email = "validuser@example.com"
        password = "validpassword"

        email_field = driver.find_element(By.NAME, LoginPageLocators.EMAIL_FIELD)
        email_field.send_keys(email)

        password_field = driver.find_element(By.NAME, LoginPageLocators.PASSWORD_FIELD)
        password_field.send_keys(password)

        login_button = driver.find_element(By.XPATH, LoginPageLocators.LOGIN_BUTTON)
        assert login_button.is_enabled(), "Login button should be enabled when credentials are entered"
        self.capture_screenshot(driver, "test_login_button_enabled_when_credentials_entered")

    def _perform_login(self, driver, email, password):
        driver.find_element(By.NAME, LoginPageLocators.EMAIL_FIELD).send_keys(email)
        driver.find_element(By.NAME, LoginPageLocators.PASSWORD_FIELD).send_keys(password)
        driver.find_element(By.XPATH, LoginPageLocators.LOGIN_BUTTON).click()

    # Adding pytest hook to capture screenshot and generate reports automatically
    @pytest.hookimpl(tryfirst=True)
    def pytest_runtest_makereport(self, item, call):
        # Only capture screenshots for failed tests
        if call.excinfo is not None:
            test_name = item.name
            screenshot_path = f"C:/Users/Lenovo/Print_field/pythonProject/screenshots/{test_name}_failed.png"
            item.instance.driver.save_screenshot(screenshot_path)
            print(f"Screenshot captured for failed test: {screenshot_path}")
