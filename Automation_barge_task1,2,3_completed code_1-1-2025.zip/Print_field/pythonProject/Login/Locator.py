class LoginPageLocators:
    EMAIL_FIELD = "email"
    PASSWORD_FIELD = "password"
    EYE_BUTTON = "//button[@id='eye-button']"
    LOGIN_BUTTON = "//button[@type='submit']"

# login_page_locators.py
from selenium.webdriver.common.by import By


class LoginPageLocators1:
    EMAIL_FIELD = (By.NAME, "email")  # Assuming the 'name' attribute for the email field is 'email'
    PASSWORD_FIELD = (By.NAME, "password")  # Assuming the 'name' attribute for the password field is 'password'
    LOGIN_BUTTON = (By.XPATH, "//button[@type='submit']")  # Update with the actual XPATH of the login button
    BUNKER_ORDERS = (By.XPATH, '//a[normalize-space()="Bunker Orders"]')
    ADD_ORDER_BUTTON = (By.XPATH, "//button[normalize-space()='Add order']")
    DATE_PICKER_ICON = (By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[2]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']")
    SELECT_DATE = (By.XPATH, "//button[normalize-space()='12']")  # Assuming the date picker is represented by the number '12'
    PORT_NAME_INPUT = (By.XPATH, "//input[@placeholder='Port name']")
    ORDER_RECEIVED_FROM_INPUT = (By.XPATH, "//input[@placeholder='Order Received From / Trader']")
    TERMINAL_NAME_INPUT = (By.XPATH, "//input[@placeholder='Terminal name']")
    C_F_NAME_INPUT = (By.XPATH, "//input[@placeholder='C/F name']")
    NOMINATED_QTY_INPUT = (By.XPATH, "//input[@name='nominatedQty']")
    AGENT_INPUT = (By.XPATH, '//input[@placeholder="Agent"]')
    ETA_PICKER = (By.XPATH, "(//button[@aria-label='Choose date'])[1]")
    ETA_SELECT_HOUR = (By.XPATH, "//button[normalize-space()='12']")
    ETA_SELECT_MINUTE = (By.XPATH, "//li[@aria-label='6 minutes']")
    ETA_SELECT_AM_PM = (By.XPATH, "//li[@aria-label='PM']")
    ETA_DONE_BUTTON = (By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[13]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']")
    STAY_HOURS_INPUT = (By.XPATH, "//input[@name='stayHours']")
    COMPANY_NAME_SELECT = (By.XPATH, "//div[@id='mui-component-select-companyName']")
    COMPANY_NAME_OPTION = (By.XPATH, "//li[@data-value='BSJPL']")
    NOMINATION_PDF_INPUT = (By.XPATH, '//input[@name="nominationPdf"]')
    WHARFAGE_FILE_INPUT = (By.XPATH, '//input[@name="wharfageFile"]')
    TRANSPORTATION_SELECT = (By.XPATH, "//div[@id='mui-component-select-transportation']")
    TRANSPORTATION_OPTION_OTHER = (By.XPATH, "//li[normalize-space()='OTHER']")
    DATE_PICKER_DONE_BUTTON = (By.XPATH, "//div[3]//div[1]//div[1]//div[1]//form[1]//div[1]//div[1]//div[20]//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]//*[name()='svg']")
    REMARK_INPUT = (By.XPATH, "//textarea[@placeholder='Remark']")
