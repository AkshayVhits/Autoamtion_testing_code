import time
import random
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException


class TestUserManagement:

    names_set = {
        "John", "Jane", "Robert", "Emily", "Michael", "Sophia", "William", "Olivia", "James", "Emma",
        "Benjamin", "Ava", "Daniel", "Isabella", "Alexander", "Mia", "Matthew", "Abigail", "Henry", "Ella",
        "Joseph", "Grace", "Samuel", "Scarlett", "David", "Amelia", "Elijah", "Chloe", "Christopher", "Evelyn",
        "Andrew", "Liam", "Gabriel", "Charlotte", "Nicholas", "Harper", "Jackson", "Lily", "Logan", "Aria",
        "Caleb", "Ethan", "Mason", "Sophie", "Nathan", "Hannah", "Isaac", "Avery", "Ryan", "Addison"
    }

    @pytest.fixture
    def driver_setup(self, request):
        driver = webdriver.Chrome()
        driver.maximize_window()

        def teardown():
            driver.quit()

        request.addfinalizer(teardown)
        return driver

    def test_admin_login(self, driver):
        driver.get("https://bett.appworkdemo.com/admin/login")
        email = driver.find_element(By.NAME, "email")
        email.send_keys("admin@betting.com")
        print("Email entered successfully")

        password = driver.find_element(By.NAME, "password")
        password.send_keys("Admin@123")
        print("Password entered successfully")

        login_button = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
        login_button.click()
        print("Admin login successful")
        time.sleep(5)

    def test_admin_login(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        assert "Betting" in driver.title  # Adjust the assertion based on the actual title

    def test_user_search(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        user_search_input = driver.find_element(By.CSS_SELECTOR, "input[aria-label='search']")
        for _ in range(5):
            random_name = random.choice(list(self.names_set))
            user_search_input.clear()
            user_search_input.send_keys(random_name)
            time.sleep(3)
            # Add assertions or validations based on the search results

    def test_download_csv(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        user_search_input = driver.find_element(By.CSS_SELECTOR, "input[aria-label='search']")
        user_search_input.clear()
        driver.refresh()
        download_csv_button = driver.find_element(By.CSS_SELECTOR, "button[type='primary']")
        download_csv_button.click()
        time.sleep(4)
        # Add assertions or validations based on the download

    def test_user_management_actions(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        action_checkbox = driver.find_element(By.XPATH, "//input[@type='checkbox'][1]")
        action_checkbox.click()
        time.sleep(4)
        # Add assertions or validations based on the actions

    def test_view_user(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        view_button = driver.find_element(By.XPATH, "(//img[@class='view-icon-btn'])[1]")
        view_button.click()
        time.sleep(4)
        # Add assertions or validations based on the user view

    def test_banking_info(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        banking_tab = driver.find_element(By.ID, "simple-tab-1")
        banking_tab.click()
        time.sleep(3)
        # Add assertions or validations based on the banking info

    def test_credit_debit_info(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        credit_tab = driver.find_element(By.ID, "simple-tab-2")
        credit_tab.click()
        time.sleep(3)
        # Add assertions or validations based on the credit/debit info

    def test_user_wallet_info(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        wallet_tab = driver.find_element(By.ID, "simple-tab-3")
        wallet_tab.click()
        time.sleep(3)
        # Add assertions or validations based on the user wallet info

    def test_my_referral_info(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        referral_tab = driver.find_element(By.ID, "simple-tab-4")
        referral_tab.click()
        time.sleep(3)
        # Add assertions or validations based on the referral info

    def test_game_info(self, driver_setup):
        driver = driver_setup
        self.admin_login(driver)
        game_tab = driver.find_element(By.ID, "simple-tab-5")
        game_tab.click()
        time.sleep(3)
        # Add assertions or validations based on the game info
