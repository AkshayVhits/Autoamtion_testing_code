import time
import random
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By


@pytest.fixture
def driver_setup(request):
    driver = webdriver.Chrome()
    driver.maximize_window()

    def teardown():
        driver.quit()

    request.addfinalizer(teardown)
    return driver


def test_admin_transaction(driver_setup):
    driver = driver_setup
    driver.get("https://bett.appworkdemo.com/admin/login")
    Email = driver.find_element(By.NAME, "email")
    Email.send_keys("admin@betting.com")
    print("Email entered successfully")
    Password = driver.find_element(By.NAME, "password")
    Password.send_keys("Admin@123")
    print("Password entered successfully")
    LoginButton = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
    LoginButton.click()
    print("Admin login successful")
    time.sleep(3)
    Transaction_request = driver.find_element(By.CSS_SELECTOR, "svg.svg.MuiSvgIcon-root MuiSvgIcon-fontSizeMedium expandless-icon css-vubbuv[aria-hidden='true'][aria-hidden='true']")
    Transaction_request.click()
    time.sleep(3)
