import time
import random
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By

class TestUserManagement:
    valid_names_set = {"John", "Jane", "Robert", "Emily", "Michael", "Sophia", "William", "Olivia", "James", "Emma",
                       "Benjamin", "Ava", "Daniel", "Isabella", "Alexander", "Mia", "Matthew", "Abigail", "Henry",
                       "Ella",
                       "Joseph", "Grace", "Samuel", "Scarlett", "David", "Amelia", "Elijah", "Chloe", "Christopher",
                       "Evelyn",
                       "Andrew", "Liam", "Gabriel", "Charlotte", "Nicholas", "Harper", "Jackson", "Lily", "Logan",
                       "Aria",
                       "Caleb", "Ethan", "Mason", "Sophie", "Nathan", "Hannah", "Isaac", "Avery", "Ryan", "Addison"}

    invalid_names_set = {"123", "!@#", "$%^", "Name123", "Invalid Name", "Special#Char", "Name_With_Underscore"}

    @pytest.fixture
    def driver_setup(self, request):
        driver = webdriver.Chrome()
        driver.maximize_window()

        def teardown():
            driver.quit()

        request.addfinalizer(teardown)
        return driver

    def test_admin_transction(self, driver_setup):
        driver = driver_setup
        driver.get("https://bett.appworkdemo.com/admin/login")
        Email = driver.find_element(By.NAME, "email")
        Email.send_keys("admin@betting.com")
        print("Email entered successfully")
        Password = driver.find_element(By.NAME, "password")
        Password.send_keys("Admin@123")
        print("Password entered successfully")
        LoginButton = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
        LoginButton.click()
        print("Admin login successful")
        time.sleep(3)
        Transaction = driver.find_element(By.CSS_SELECTOR, "a[href='/admin/transaction-history']")
        Transaction.click()
        time.sleep(3)
        select_date = driver.find_element(By.CSS_SELECTOR, "input[placeholder='Select date']")
        select_date.click()
        time.sleep(3)
        date = driver.find_element(By.CSS_SELECTOR, "td.ant-picker-cell[title='2024-03-05']")
        date.click()
        time.sleep(3)

    def test_admin_search(self, driver_setup):
        driver = driver_setup
        driver.get("https://bett.appworkdemo.com/admin/login")
        Email = driver.find_element(By.NAME, "email")
        Email.send_keys("admin@betting.com")
        print("Email entered successfully")
        Password = driver.find_element(By.NAME, "password")
        Password.send_keys("Admin@123")
        print("Password entered successfully")
        LoginButton = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
        LoginButton.click()
        print("Admin login successful")
        time.sleep(3)
        Transaction = driver.find_element(By.CSS_SELECTOR, "a[href='/admin/transaction-history']")
        Transaction.click()
        time.sleep(3)
        select_date = driver.find_element(By.CSS_SELECTOR, "input[placeholder='Select date']")
        select_date.click()
        time.sleep(3)
        date = driver.find_element(By.CSS_SELECTOR, "td.ant-picker-cell[title='2024-03-05']")
        date.click()
        time.sleep(3)
        search = driver.find_element(By.CSS_SELECTOR, "input[placeholder='Search']")
        random_name = random.choice(list(self.valid_names_set.union(self.invalid_names_set)))
        search.send_keys(random_name)
        time.sleep(3)


    def test_admin_download(self, driver_setup):
        driver = driver_setup
        driver.get("https://bett.appworkdemo.com/admin/login")
        Email = driver.find_element(By.NAME, "email")
        Email.send_keys("admin@betting.com")
        print("Email entered successfully")
        Password = driver.find_element(By.NAME, "password")
        Password.send_keys("Admin@123")
        print("Password entered successfully")
        LoginButton = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
        LoginButton.click()
        print("Admin login successful")
        time.sleep(3)
        Transaction = driver.find_element(By.CSS_SELECTOR, "a[href='/admin/transaction-history']")
        Transaction.click()
        time.sleep(3)
        select_date = driver.find_element(By.CSS_SELECTOR, "input[placeholder='Select date']")
        select_date.click()
        time.sleep(3)
        date = driver.find_element(By.CSS_SELECTOR, "td.ant-picker-cell[title='2024-03-05']")
        date.click()
        time.sleep(3)
        search = driver.find_element(By.CSS_SELECTOR, "input[placeholder='Search']")
        random_name = random.choice(list(self.valid_names_set.union(self.invalid_names_set)))
        search.send_keys(random_name)
        time.sleep(3)
        download = driver.find_element(By.CSS_SELECTOR, "img.svg-download-csv")
        download.click()
