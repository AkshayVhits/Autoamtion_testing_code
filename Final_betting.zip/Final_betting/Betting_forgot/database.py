import random

class DataBase:
    a = {1, 2, 3, 4, 5, 6, 7, 8, 9}
    b = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
         'W',
         'X', 'Y', 'Z'}
    c = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
         'w',
         'x', 'y', 'z'}

    @staticmethod
    def generate_email():
        email_username_length = random.choice(list(DataBase.a))
        email_username = ''.join(
            random.choice(list(DataBase.b.union(DataBase.c))) for _ in range(email_username_length))
        domain = random.choice(["@", "@.com", "@domain", "@domain.", "@.domain.com", "@domain..com", "@domain#.com",
                                "@domain.c", "@-domain.com", "@domain-.com", "@_domain.com", "@domain_.com"])
        email = f'{email_username}{domain}'
        return email

    @staticmethod
    def generate_digit_number_name():
        digit = random.randint(1, 9)
        name_length = random.randint(1, 9)
        name = ''.join(random.choice(list(DataBase.b.union(DataBase.c))) for _ in range(name_length))
        return f'{digit}{name}'
