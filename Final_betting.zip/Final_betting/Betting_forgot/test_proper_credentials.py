from selenium.webdriver.common.by import By
from database import DataBase

def test_admin_login_with_proper_credentials(driver_setup):
    driver = driver_setup

    # Number of iterations for the loop
    driver.get("https://bett.appworkdemo.com/admin/forgot-password")

    # Admin login
    Email = driver.find_element(By.NAME, "email")
    Email.send_keys("admin@betting.com")
    print("Email entered successfully")
    LoginButton = driver.find_element(By.XPATH, "//button[@type='submit']")
    LoginButton.click()
    print("Admin login successful")

    # Ensure login was successful (replace with appropriate assertions)
    #assert "dashboard" in driver.current_url.lower()

    driver.refresh()
