import time
import pytest
from login_test import test_admin_login_with_generated_credentials, test_admin_login_with_proper_credentials
from driver_setup import driver_setup  # Import the driver_setup fixture

def test_run_all_login_tests(driver_setup):
    test_admin_login_with_generated_credentials(driver_setup)
    test_admin_login_with_proper_credentials(driver_setup)

if __name__ == "__main__":
    pytest.main(["-v", "main.py::test_run_all_login_tests"])
