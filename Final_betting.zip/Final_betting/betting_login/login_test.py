import time
import pytest
from selenium.webdriver.common.by import By
from data_base import DataBase
from driver_setup import driver_setup

def test_admin_login_with_generated_credentials(driver_setup):
    driver = driver_setup
    num_iterations = 10

    for _ in range(num_iterations):
        driver.get("https://bett.appworkdemo.com/admin/login")
        Email = driver.find_element(By.NAME, "email")
        Email.send_keys(DataBase.generate_email())
        print("Email entered successfully")
        Password = driver.find_element(By.NAME, "password")
        Password.send_keys(DataBase.generate_password())
        print("Password entered successfully")
        LoginButton = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
        LoginButton.click()
        print("Admin login successful")
        driver.refresh()

def test_admin_login_with_proper_credentials(driver_setup):
    driver = driver_setup
    driver.get("https://bett.appworkdemo.com/admin/login")
    Email = driver.find_element(By.NAME, "email")
    Email.send_keys("admin@betting.com")
    print("Email entered successfully")
    Password = driver.find_element(By.NAME, "password")
    Password.send_keys("Admin@123")
    print("Password entered successfully")
    LoginButton = driver.find_element(By.XPATH, "//button[contains(text(),'Login')]")
    LoginButton.click()
    print("Admin login successful")
    time.sleep(3)
