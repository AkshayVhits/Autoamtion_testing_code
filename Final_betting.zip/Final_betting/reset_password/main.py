import pytest
from test_generated_credentials import test_admin_login_with_generated_credentials

def test_run_all_login_tests():
    # Run the test_admin_login_with_generated_credentials function
    pytest.main(["-v", "test_generated_credentials.py::test_admin_login_with_generated_credentials"])
