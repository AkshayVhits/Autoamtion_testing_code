from selenium.webdriver.common.by import By
import time
from database import DataBase
from fixture import driver_setup

def test_admin_login_with_generated_credentials(driver_setup):
    driver = driver_setup

    # Number of iterations for the loop
    driver.get("https://bett.appworkdemo.com/admin/forgot-password")

    # Admin login
    Email = driver.find_element(By.NAME, "email")
    Email.send_keys("admin@betting.com")
    print("Email entered successfully")
    LoginButton = driver.find_element(By.XPATH, "//button[@type='submit']")
    LoginButton.click()
    print("Reset_email entered successful")

    # Ensure login was successful (replace with appropriate assertions)
    # assert "dashboard" in driver.current_url.lower()

    time.sleep(3)
    # ==============================================================================
    num_iterations = 50

    for _ in range(num_iterations):

        # Generate new random OTP values for each iteration
        otp_values = [DataBase.generate_otp() for _ in range(4)]

        OTP_1 = driver.find_element(By.XPATH, "(//input[@autocomplete='one-time-code'])[1]")
        OTP_1.send_keys(str(otp_values[0]))

        OTP_2 = driver.find_element(By.XPATH, "(//input[@autocomplete='one-time-code'])[2]")
        OTP_2.send_keys(str(otp_values[1]))

        OTP_3 = driver.find_element(By.XPATH, "(//input[@autocomplete='one-time-code'])[3]")
        OTP_3.send_keys(str(otp_values[2]))

        OTP_4 = driver.find_element(By.XPATH, "(//input[@autocomplete='one-time-code'])[4]")
        OTP_4.send_keys(str(otp_values[3]))

        Submit_button = driver.find_element(By.XPATH, "//button[@data-testid='button']")
        Submit_button.click()
        time.sleep(3)
        print("OTP values entered successfully")
