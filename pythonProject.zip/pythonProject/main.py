
import time
from selenium import webdriver

import Login


# Set expected URL after login
expected_url = "https://stock-charting.appworkdemo.com/success"

# Setup Chrome WebDriver with ChromeDriverManager
driver = webdriver.Chrome()

# Get URL from command line arguments or use default
driver.get("https://stock-charting.appworkdemo.com")
driver.maximize_window()

time.sleep(4)  # Wait for the page to load

try:
    # Uncomment this section if you want to perform registration
    # Registation.perform_registration(driver, expected_url)
    # print("Registration completed successfully.")

    # Navigate to project URL (make sure you set the correct URL here)
    driver.get(expected_url)  # Assuming you want to check if this is the success page

    # Perform login
    Login.perform_login(driver)
    print("Login attempt completed.")
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    time.sleep(10)  # Wait before quitting
    driver.quit()  # Ensure the driver is quit properly
