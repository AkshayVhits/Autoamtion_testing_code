from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import Locator
import data_base
import time


def perform_registration(driver, expected_url):
    wait = WebDriverWait(driver, 1)

    for attempt in range(20):
        try:

            random_first_name = data_base.create_random_firstname()
            random_last_name = data_base.create_random_lastname()
            random_email = data_base.create_random_email()
            random_password = data_base.create_random_password()

            print("First name =", random_first_name)
            print("Last name =", random_last_name)
            print("email =", random_email)
            print("password =", random_password)
            print("confirm password =", random_password)

            driver.refresh()

            first_name = wait.until(ec.visibility_of_element_located(Locator.First_Name_Registration))
            first_name.clear()
            first_name.send_keys(random_first_name)

            last_name = wait.until(ec.visibility_of_element_located(Locator.Last_Name_Registration))
            last_name.clear()
            last_name.send_keys(random_last_name)

            email_input = wait.until(ec.visibility_of_element_located(Locator.Email_Registration))
            email_input.clear()
            email_input.send_keys(random_email)

            password = wait.until(ec.visibility_of_element_located(Locator.Password_Registration))
            password.clear()
            password.send_keys(random_password)

            confirm_password = wait.until(ec.visibility_of_element_located(Locator.Confirm_Password_Registration))
            confirm_password.clear()
            confirm_password.send_keys(random_password)

            eye_button_1 = wait.until(ec.visibility_of_element_located(Locator.Eye_Button_Registration_1))
            eye_button_1.click()

            eye_button_2 = wait.until(ec.visibility_of_element_located(Locator.Eye_Button_Registration_2))
            eye_button_2.click()

            registration_submit = wait.until(ec.visibility_of_element_located(Locator.Registration_Submit))
            registration_submit.click()

            current_url = driver.current_url

            if current_url == expected_url:
                print(f"Attempt {attempt + 1}: Registration successful")
                break
            else:
                print(f"Attempt {attempt + 1}: Registration failed")
                errors = []

                # Check First Name
                if not (wait.until(ec.presence_of_element_located((By.ID, Locator.First_Name_Registration)))
                        .is_displayed()):
                    errors.append("First Name Error: Not displayed or incorrect")

                # Check Last Name
                if not (wait.until(ec.presence_of_element_located((By.ID, Locator.Last_Name_Registration)))
                        .is_displayed()):
                    errors.append("Last Name Error: Not displayed or incorrect")

                # Check Email
                if not (wait.until(ec.presence_of_element_located((By.ID, Locator.Email_Registration)))
                        .is_displayed()):
                    errors.append("Email Error: Not displayed or incorrect")

                # Check Password
                if not (wait.until(ec.presence_of_element_located((By.ID, Locator.Password_Registration)))
                        .is_displayed()):
                    errors.append("Password Error: Not displayed or incorrect")

                # Check Confirm Password
                if not (wait.until(ec.presence_of_element_located((By.ID, Locator.Confirm_Password_Registration)))
                        .is_displayed()):
                    errors.append("Confirm Password Error: Not displayed or incorrect")

                for error in errors:
                    print(error)
                print(f"Email = {random_email}\nPassword = {random_password}")

        except NoSuchElementException as e:
            print(f"Element not found during attempt {attempt + 1}: {e}")
        except TimeoutException as e:
            print(f"Timeout occurred during attempt {attempt + 1}: {e}")
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
        finally:
            time.sleep(1)
    else:
        print("All attempts failed.")
