import http.server
import socketserver
import subprocess
import json

PORT = 8080

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/run-test':
            try:
                # Run the main.py script
                result = subprocess.run(['python', 'main.py'], check=True, capture_output=True, text=True)

                # Send a success response
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')  # Allow CORS
                self.end_headers()

                # Send the output of the script back to the client
                self.wfile.write(json.dumps({'message': 'Test case executed successfully!', 'output': result.stdout}).encode())
            except subprocess.CalledProcessError as e:
                # Send an error response
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')  # Allow CORS
                self.end_headers()

                # Send the error message
                self.wfile.write(json.dumps({'message': 'Error executing test case!', 'error': e.stderr}).encode())
        else:
            super().do_GET()

# Start the server
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving at port {PORT}")
    httpd.serve_forever()
