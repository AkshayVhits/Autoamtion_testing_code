import time
import random
from selenium import webdriver
from selenium.webdriver.common.by import By
import pytest

def clear_fields(random_email, random_password):
    # Print cleared values
    print(f"Random Email: {random_email}")
    print(f"Random Password: {random_password}")
    print("Page Refreshed")

# Database
email_set = {"john.doe123@gmail.com", "support@company.org", "invalid_email", "missing_at.com", "user@missing_tld", "user@domain@domain.com", "user@.com", "@missing_username.com", "user@domain_with_spaces .com"}
password_set = {"weakpassword", "1234567890", "abcdefghijk", "P@ssw0rd", "Short!1", "NoSpecialChars123", "SpacesNotAllowed", "PasswordWith Spaces", "password", ""}

# Test Setup
@pytest.fixture(scope="module")
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("https://betting.appworkdemo.com/admin/login")
    yield driver
    driver.quit()

# Test case
@pytest.mark.negative
def test_login_negative(driver):
    for _ in range(10):  # Run the loop 10 times
        # Identifiers (re-locate elements after page refresh)
        # Refresh the page
        driver.refresh()
        admin_email = driver.find_element(By.NAME, "email")
        admin_password = driver.find_element(By.NAME, "password")
        admin_submit = driver.find_element(By.XPATH, "//button[@type='submit']")

        # Pick random email and password from sets
        random_email = random.choice(tuple(email_set))
        random_password = random.choice(tuple(password_set))

        # Fill the form using random values
        admin_email.send_keys(random_email)
        admin_password.send_keys(random_password)

        # Print random values before submitting
        clear_fields(random_email, random_password)

        # Perform other actions or submit the form as needed
        admin_submit.click()

        # Add a delay to observe the result
        time.sleep(2)



# Additional test case
@pytest.mark.positive
def test_login_positive(driver):
    # Refresh the page
    driver.refresh()
    admin_email = driver.find_element(By.NAME, "email")
    admin_password = driver.find_element(By.NAME, "password")
    admin_submit = driver.find_element(By.XPATH, "//button[@type='submit']")

    admin_email.send_keys("Admin@Betting.com")
    print("Email :- Admin@Betting.com")
    admin_password.send_keys("Admin@123")
    print("Password :- Admin@123")
    admin_submit.click()

    # Add a delay to observe the result
    time.sleep(4)
