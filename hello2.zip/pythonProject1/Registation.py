import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
import Locator
import data_base

def perform_registration(driver, expected_url):
    wait = WebDriverWait(driver, 10)  # Increased wait time for elements to load

    for attempt in range(10):  # Retry up to 10 times
        try:
            # Generate random data for the registration form
            random_first_name = data_base.create_random_firstname()
            random_last_name = data_base.create_random_lastname()
            random_email = data_base.create_random_email()
            random_password = data_base.create_random_password()

            # Refresh the page before starting a new registration attempt
            driver.refresh()

            # Wait for and fill in the registration fields
            first_name = wait.until(ec.visibility_of_element_located(Locator.First_Name_Registration))
            first_name.clear()
            first_name.send_keys(random_first_name)

            last_name = wait.until(ec.visibility_of_element_located(Locator.Last_Name_Registration))
            last_name.clear()
            last_name.send_keys(random_last_name)

            email_input = wait.until(ec.visibility_of_element_located(Locator.Email_Registration))
            email_input.clear()
            email_input.send_keys(random_email)

            password = wait.until(ec.visibility_of_element_located(Locator.Password_Registration))
            password.clear()
            password.send_keys(random_password)

            confirm_password = wait.until(ec.visibility_of_element_located(Locator.Confirm_Password_Registration))
            confirm_password.clear()
            confirm_password.send_keys(random_password)

            # Click the "eye" buttons to reveal the passwords (if applicable)
            eye_button_1 = wait.until(ec.element_to_be_clickable(Locator.Eye_Button_Registration_1))
            eye_button_1.click()

            eye_button_2 = wait.until(ec.element_to_be_clickable(Locator.Eye_Button_Registration_2))
            eye_button_2.click()

            # Submit the registration form
            registration_submit = wait.until(ec.element_to_be_clickable(Locator.Registration_Submit))
            registration_submit.click()

            # Optional: Verify URL to ensure successful registration
            WebDriverWait(driver, 10).until(lambda driver: driver.current_url != expected_url)

            print(f"Registration attempt {attempt + 1} succeeded.")
            return True  # Successful registration

        except (NoSuchElementException, TimeoutException, StaleElementReferenceException) as e:
            print(f"Attempt {attempt + 1} failed due to error: {str(e)}. Retrying...")
            time.sleep(2)  # Optional sleep time before retrying

    print("All registration attempts failed.")
    return False  # All attempts failed
