from selenium.webdriver.common.by import By

# Define locators for the Login
EMAIL_INPUT_Login = (By.ID, 'fullWidth.email')
PASSWORD_INPUT_Login = (By.NAME, 'password')
EYE_BUTTON_Login = (By.XPATH, '//button[@type="button"]')
LOGIN_BUTTON_Login = (By.XPATH, '//button[@type="submit"]')

# Define locators for the registation
First_Name_Registration = (By.NAME, "firstName")
Last_Name_Registration = (By.NAME, "lastName")
Email_Registration = (By.NAME, "email")
Password_Registration = (By.NAME, "password")
Confirm_Password_Registration = (By.NAME, "confirmPassword")
Eye_Button_Registration_1 = (By.XPATH, "(//button[@type='button'])[1]")
Eye_Button_Registration_2 = (By.XPATH, "(//button[@type='button'])[2]")
Registration_Submit = (By.XPATH, "//button[@type='submit']")

# Define locators for the Profile
Profile_Image = (By.XPATH, "//label[@role='button']")
Profile_Full_Name = (By.XPATH, "//input[@name='fullName']")
Profile_Email = (By.XPATH, "//input[@name='email']")
Profile_Mobile_Number = (By.XPATH, "//input[@name='mobileNumber']")


