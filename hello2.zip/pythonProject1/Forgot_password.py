from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import Locator
import data_base
import time


def forgot_password(driver):
    wait = WebDriverWait(driver, 10)
    for attempt in range(20):
        try:
            driver.refresh()
            email_input = wait.until(EC.visibility_of_element_located(Locator.Email_Forgot_Email))
            email_input.clear()
            email_input.send_keys(data_base.random_email)
            print(f"Attempt {attempt + 1}: Email {data_base.random_email} entered successfully.")
            break
        except TimeoutException:
            print(f"Timeout while waiting for elements on attempt {attempt + 1}. Retrying...")
        except NoSuchElementException:
            print(f"Element not found on attempt {attempt + 1}. Retrying...")
        except Exception as e:
            print(f"An error occurred on attempt {attempt + 1}: {e}. Retrying...")
        time.sleep(2)

    else:
        print("Failed to complete the forgot password process after 20 attempts.")
