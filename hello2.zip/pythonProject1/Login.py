import json
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Locator
import data_base
import time


def perform_login(driver, results=None):
    wait = WebDriverWait(driver, 10)

    for attempt in range(20):
        try:

            driver.refresh()

            email_input = wait.until(EC.visibility_of_element_located(Locator.EMAIL_INPUT_Login))
            email_input.clear()
            email_input.send_keys(data_base.random_email)

            password_input = wait.until(EC.visibility_of_element_located(Locator.PASSWORD_INPUT_Login))
            password_input.clear()
            password_input.send_keys(data_base.random_password)

            eye_button = wait.until(EC.element_to_be_clickable(Locator.EYE_BUTTON_Login))
            eye_button.click()

            login_button = wait.until(EC.element_to_be_clickable(Locator.LOGIN_BUTTON_Login))
            login_button.click()

            current_url = driver.current_url
            expected_url = "https://stock-charting.appworkdemo.com/user/dashboard"

            if current_url == expected_url:
                result = {
                    'attempt': attempt + 1,
                    'email': data_base.random_email,
                    'status': 'Login successfully'
                }
                results.append(result)
                print(f"Attempt {attempt + 1}: Email = {data_base.random_email}\nPassword = {data_base.random_password}\nStatus = Login successfully")
            else:
                result = {
                    'attempt': attempt + 1,
                    'email': data_base.random_email,
                    'status': 'Invalid Login'
                }
                results.append(result)
                print(f"Attempt {attempt + 1}: Please enter valid email\nEmail = {data_base.random_email}\nPassword = {data_base.random_password}\nStatus = Invalid Login")

        except Exception as e:
            result = {
                'attempt': attempt + 1,
                'email': data_base.random_email,
                'status': f'Error: {str(e)}'
            }
            results.append(result)
            print(f"Attempt {attempt + 1}: An error occurred: {e}\nEmail = {data_base.random_email}\nPassword = {data_base.random_password}\nStatus = Invalid Login")

        time.sleep(2)

    # Save the results to a JSON file
    with open('login_results.json', 'w') as f:
        json.dump(results, f, indent=4)

    driver.quit()