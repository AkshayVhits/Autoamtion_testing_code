from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import Locator
import data_base
import time

def reset_password(driver):
    wait = WebDriverWait(driver, 10)

    for attempt in range(20):
        try:
            driver.refresh()
            new_password_input = wait.until(EC.visibility_of_element_located(Locator.NEW_PASSWORD_INPUT))
            new_password_input.clear()
            new_password_input.send_keys(data_base.random_password)
            confirm_password_input = wait.until(EC.visibility_of_element_located(Locator.CONFIRM_PASSWORD_INPUT))
            confirm_password_input.clear()
            confirm_password_input.send_keys(data_base.random_password)
            submit_button = wait.until(EC.element_to_be_clickable(Locator.RESET_PASSWORD_SUBMIT_BUTTON))
            submit_button.click()

            print(f"Attempt {attempt + 1}: New password entered and submitted successfully.")

            login_with_new_password(driver)
            break
        except TimeoutException:
            print(f"Timeout while waiting for elements on attempt {attempt + 1}. Retrying...")
        except NoSuchElementException:
            print(f"Element not found on attempt {attempt + 1}. Retrying...")
        except Exception as e:
            print(f"An error occurred on attempt {attempt + 1}: {e}. Retrying...")
        time.sleep(2)

    else:
        print("Failed to complete the reset password process after 20 attempts.")


def login_with_new_password(driver):
    wait = WebDriverWait(driver, 10)

    for attempt in range(20):
        try:
            driver.get("https://example.com/login")
            email_input = wait.until(EC.visibility_of_element_located(Locator.EMAIL_INPUT_LOGIN))
            email_input.clear()
            email_input.send_keys(data_base.random_email)
            password_input = wait.until(EC.visibility_of_element_located(Locator.PASSWORD_INPUT_LOGIN))
            password_input.clear()
            password_input.send_keys(data_base.new_password)
            login_button = wait.until(EC.element_to_be_clickable(Locator.LOGIN_BUTTON))
            login_button.click()
            print(f"Attempt {attempt + 1}: Successfully logged in with the new password.")

            break

        except TimeoutException:
            print(f"Timeout while waiting for elements on attempt {attempt + 1}. Retrying...")
        except NoSuchElementException:
            print(f"Element not found on attempt {attempt + 1}. Retrying...")
        except Exception as e:
            print(f"An error occurred on attempt {attempt + 1}: {e}. Retrying...")

        time.sleep(2)

    else:
        print("Failed to log in with the new password after 20 attempts.")
