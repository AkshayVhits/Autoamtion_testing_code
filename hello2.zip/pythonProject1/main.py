import time
from selenium import webdriver
import Login
import Registation

expected_url = "https://stock-charting.appworkdemo.com/register"
driver = webdriver.Chrome()
driver.get("https://stock-charting.appworkdemo.com/register")
driver.maximize_window()

time.sleep(4)

try:
    Registation.perform_registration(driver, expected_url)
    print("Registration completed successfully.")
    # driver.get(expected_url)
    # Login.perform_login(driver)
    # print("Login attempt completed.")
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    time.sleep(10)
    driver.quit()
