from selenium import webdriver
import time
import Login
import Registation


expected_url = "https://stock-charting.appworkdemo.com/success"

driver = webdriver.Chrome()


driver.get("https://stock-charting.appworkdemo.com/register")
driver.maximize_window()


time.sleep(4)


try:
    Registation.perform_registration(driver, expected_url)
    print("Registration completed successfully.")
except Exception as e:
    print(f"An error occurred during registration: {e}")


time.sleep(4)

driver.get("https://stock-charting.appworkdemo.com")

try:
    Login.perform_login(driver)
    print("Login attempt completed.")
except Exception as e:
    print(f"An error occurred during login: {e}")


time.sleep(10)


driver.quit()
