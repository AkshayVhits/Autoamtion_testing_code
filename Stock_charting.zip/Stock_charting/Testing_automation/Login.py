from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import Locator
import data_base
import time


def perform_login(driver):
    wait = WebDriverWait(driver, 10)

    for attempt in range(20):
        try:

            driver.refresh()

            email_input = wait.until(EC.visibility_of_element_located(Locator.EMAIL_INPUT_Login))
            email_input.clear()
            email_input.send_keys(data_base.random_email)

            password_input = wait.until(EC.visibility_of_element_located(Locator.PASSWORD_INPUT_Login))
            password_input.clear()
            password_input.send_keys(data_base.random_password)

            eye_button = wait.until(EC.element_to_be_clickable(Locator.EYE_BUTTON_Login))
            eye_button.click()

            login_button = wait.until(EC.element_to_be_clickable(Locator.LOGIN_BUTTON_Login))
            login_button.click()

            current_url = driver.current_url
            expected_url = "https://stock-charting.appworkdemo.com/user/dashboard"

            if current_url == expected_url:
                print(f"Attempt {attempt + 1}: Email = {data_base.random_email}\nPassword = {data_base.random_password}"
                      f"\nStatus = Login successfully")
            else:
                print(f"Attempt {attempt + 1}:", "Please enter valid email",
                      "Email =", {data_base.random_email}, "\n", "Password =", {data_base.random_password},
                      "\n" "Status = Invalid Login")

        except Exception as e:
            print(f"Attempt {attempt + 1}: An error occurred: {e}", "Please enter valid email", "\n"
                  "Email =", {data_base.random_email}, "\n", "Password =", {data_base.random_password},
                  "\n" "Status = Invalid Login")

        time.sleep(2)

    driver.quit()
