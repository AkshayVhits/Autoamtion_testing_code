from flask import Flask, request, jsonify, render_template
import requests
import json
import asyncio

app = Flask(__name__)

HUGGINGFACE_API_URL = "https://api-inference.huggingface.co/models/meta-llama/Llama-3.2-1B"
HUGGINGFACE_API_KEY = "Bearer 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"  # Replace with your Hugging Face API key

async def query(data):
    # Make a request to the Hugging Face API
    response = requests.post(
        HUGGINGFACE_API_URL,
        headers={
            "Authorization": HUGGINGFACE_API_KEY,
            "Content-Type": "application/json",
        },
        data=json.dumps(data),
    )

    if response.status_code == 200:
        result = response.json()
        return result
    else:
        return {"error": "Failed to fetch explanation"}, response.status_code

@app.route('/')
def index():
    # Render the HTML page when accessing the root URL
    return render_template('Manual-testing.html')

@app.route('/explain', methods=['GET'])
def explain():
    # Get the topic from the query parameters
    topic = request.args.get('topic')

    if not topic:
        return jsonify({'error': 'No topic provided'}), 400

    # Prepare the input data for the query
    input_data = {"inputs": topic}

    # Run the async query
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    response = loop.run_until_complete(query(input_data))

    # Check for errors in the response
    if 'error' in response:
        return jsonify(response), 500  # Return error response with a 500 status

    # Check if the response is a list and extract the generated text
    if isinstance(response, list) and len(response) > 0:
        explanation = response[0].get("generated_text", "No explanation available.")  # Adjust based on actual response structure
    else:
        explanation = "No explanation available."

    return jsonify({'explanation': explanation})

if __name__ == '__main__':
    app.run(debug=True)
