import string
import random
# Lists of invalid data
INVALID_EMAILS = [
    "plainaddress",                      # Missing "@" and domain
    "@missingusername.com",              # Missing username
    "username@.com",                     # Domain starts with a dot
    "username@com",                      # Missing top-level domain
    "username@site..com",                # Double dots in domain
    "username@site.c",                   # Incomplete top-level domain
    "username@site@domain.com",          # Multiple "@" symbols
    "username@domain..com",              # Double dots in domain
    "username@domain.c@com",             # Multiple "@" symbols
    "username@domain@domain.com",        # Multiple "@" symbols
    "username@domain.c",                 # Incomplete top-level domain
    "username@.domain.com",              # Domain starts with a dot
    "username@.domain..com",             # Dot at the start of domain and double dots
    "username@domain.c@domain.com",      # Multiple "@" symbols
    "user@domain..com",                  # Double dots in domain
    "user@domain@subdomain.com",         # Multiple "@" symbols
    "user@domain.com@subdomain",         # Multiple "@" symbols
    "user@domain@subdomain@domain.com",  # Multiple "@" symbols
    "        "                          # Only spaces
]

INVALID_PASSWORDS = [
    "password",        # Commonly used password
    "123456",          # Numeric only
    "qw",              # Too short
    "abc123",          # Simple pattern
    "password1",       # Common password with a number
    "let",             # Too short
    "welcome",         # Common word
    "123456789",       # Numeric only, slightly longer
    "iloveyou",        # Common phrase
    "admin123",        # Common username-password combination
    "1234567",         # Numeric only
    "qwert%#@%",       # Special characters but weak
    "password123",     # Common pattern with numbers
    "123456@@78",      # Numeric with special characters, but still weak
    "admin1234",       # Common username-password combination with more numbers
    "password1!",      # Common password with a special character
    "123456a",         # Numeric with a single letter
    "letmein1",        # Common phrase with a number
    "monkey123",       # Common phrase with numbers
    "123456qwerty",    # Numeric followed by a common pattern
    "   "              # Only spaces
]

INVALID_FIRST_NAMES = [
    "",               # Empty string
    "a",              # Single character
    "1",              # Single digit
    "12345",          # Numeric only
    "John!",          # Contains special character
    "Anna123",        # Contains numbers
    "J@ne",           # Special character
    "x",              # Single character
    "  ",             # Space only
    "??",             # Special characters
    "@name",          # Starts with special character
    "john.doe",       # Contains dot
    "user@name",      # Contains @ symbol
    "abcdefghij"*2,   # Too long and repetitive
    "Name Name",      # Contains space
    "12345678901234567890",   # Too long
    "!!!",            # Only special characters
    "Name1234567890",   # Long and contains numbers
    "#$%^&*",         # Only special characters
    "1a2b3c",         # Mixed but invalid
    "Name$",          # Ends with special character
]

INVALID_LAST_NAMES = [
    "",               # Empty string
    "a",              # Single character
    "1",              # Single digit
    "12345",          # Numeric only
    "Doe!",           # Contains special character
    "Smith123",       # Contains numbers
    "O'Connor",       # Contains special character (apostrophe)
    "N@me",           # Contains special character (at sign)
    "S*ith",          # Contains special character (asterisk)
    "Johnson-",       # Contains special character (hyphen)
    "Brown ",         # Trailing space
    "Green12345",     # Numeric and long
    "White@",         # Contains special character (at sign)
    "Lee!!",          # Contains special characters (exclamation marks)
    "Anderson..",     # Contains double dots
    "Miller#name",    # Contains special character (hash)
    "Martínez",       # Special characters (accented letters, not valid in some systems)
    "      ",         # Only spaces
    "H@rris",         # Contains special character (at sign)
    "Zhang*Liu",      # Contains special character (asterisk)
    "Wang1234",       # Contains numbers
]


# Function to generate random strings
def generate_random_string(length=8):
    letters = string.ascii_letters + string.digits
    return ''.join(random.choice(letters) for _ in range(length))


# Functions to create random invalid data
def create_random_email():
    return random.choice(INVALID_EMAILS)


def create_random_password():
    return random.choice(INVALID_PASSWORDS)


def create_random_firstname():
    return random.choice(INVALID_FIRST_NAMES)


def create_random_lastname():
    return random.choice(INVALID_LAST_NAMES)

# Example usage


random_email = create_random_email()
random_username = generate_random_string(10)  # Create random username
random_password = create_random_password()


